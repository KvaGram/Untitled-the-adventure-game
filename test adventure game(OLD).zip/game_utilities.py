#this script binds together all scripts such as all others can access each other in a global scope
import sys
import tkinter as tk
from tkinter import filedialog
import time

def loadGame():
    root = tk.Tk()
    root.withdraw()

    file_path = filedialog.askopenfilename()
    print(file_path)
    #TODO try convert textfile to save-file, and load latest room
    return {}

def choose(list):
    valid = False
    inp = 0 #placeholder value
    while not valid:
        print("\tenter choice number {0} to {1}".format(1, len(list)))
        for i in range (len(list)):
            print ("\t {0} - {1}".format(i+1, list[i]))
        inp = input()
        try:
            inp = int(inp) - 1
        except:
            print("Please enter a valid number")
            continue
        if (inp < 0 or inp >= len(list)):
            print("Sorry, that is not an option.")
            continue
        valid = True
    #print("you chose {0}".format(list[inp-1]))
    return inp
def yesno(message = "Please select"):
    while True:
        print("\t" + message)
        print("\t[Y] yes")
        print("\t[N] no")
        print()
        inp = input()
        if(inp[0] is "y" or inp[0] is "Y"):
            return True
        elif(inp[0] is "n" or inp[0] is "N"):
            return False
def truefalse(message = "Please select"):
    while True:
        print("\t" + message)
        print("\t[T] True")
        print("\t[F] False")
        print()
        inp = input()
        if(inp[0] is "t" or inp[0] is "T"):
            return True
        elif(inp[0] is "f" or inp[0] is "F"):
            return False        

def rolltext(txt, linepause):
    lines = txt.splitlines()
    for l in lines:
        print(l)
        time.sleep(linepause)
