import time

import game_utilities as game

import room_apartment
import about
import WheelC as wheel

#version number. Major, minor, hotfix.
VERSION = [0, 0, 1]


def build_world():
    world = {}
    world['apartment'] = room_apartment.main
    world['about'] = about.main
    world["core"] = wheel.core
    world["innerA"] = wheel.innerA
    world["innerB"] = wheel.innerB
    world["middleA"] = wheel.innerA
    world["middleB"] = wheel.innerB
    world["outerA"] = wheel.outerA
    world["outerB"] = wheel.outerB
    world["ladder"] = wheel.ladder
    world["Airlock"] = wheel.wheelCAirlock

    return world

def start():
    world = build_world()
    save = savadata(VERSION)

    def game_loop():
        while True:
            roomReq = save.getdata("room")
            if(roomReq == None):
                #error in the save or new game
                world['apartment'](save)
                continue
            #space to check for special conditions
            if(save.getdata("GAME OVER")):
                print("""
----------------- GAME OVER ----------------------
                """)
                return
            #general rule
            room = None
            try:
                room = world[roomReq]
            except:
                room = None
            if(room):
                room(save)
            else:
                print("""
---------------------- !!! ----------------------
    Sorry, something went wrong.
    The game could not find {0}
    The game will now end.
    Do you wish to save the game first?
---------------------- !!! ----------------------
                """.format(roomReq))
                if(game.yesno("Save game?")):
                    save.savegame()
                return
        #end game loop
    #end game loop function

    print("Welcome to")
    f = open("title.txt", 'r', encoding="utf-8")
    titlecard = f.read()
    game.rolltext(titlecard, 0.05)
    f.close()
    time.sleep(1)
    print()
    while(True):
        print("Untitled! The adventure game")
        print("MAIN MENU")
        choices = ["New Game", "Load Game (NOT IMPLEMENTED YET)", "About", "End game"]
        choice = game.choose(choices)
        if(choice == 0):
            game_loop()
            continue
        if(choice == 1):
            save.loadgame()
            game_loop()
            continue
        if(choice == 2):
            world['about']()#starts credits roll
            continue
        if(choice == 3):
            return
class savadata:
    # data contains all save data, including choices and the player's location
    data = {}
    # version is saved as an array of 3 numbers to easly warn of potential version conflicts
    version = []
    def __init__(self, version):
        self.data = {}
        self.version = version
    def getdata(self, name):
        try:
            return self.data[name]
        except:
            return None
    def setdata(self, name, value):
        self.data[name] = value
    def savegame(self):
        print("Sorry, save game has not been implemented yet.")
    def loadgame(self):
        print("Sorry load game has not been implemented yet.")
    #sets the room save data.
    #example use
    # return save.goto("middleA")
    #return statment may be seperate as goto does not return value
    #but it is symbolic as you usually use this to move from a room (module)
    def goto(self, room):
        self.setdata("prevroom", self.getdata('room'))
        self.setdata("room", room)
    def versionText(self):
        return "v{0}.{1}.{2}".format(self.version[0], self.version[1], self.version[2])
start()