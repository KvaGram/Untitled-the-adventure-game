import game_utilities as game

#barebones placeholder for chapter 1: Wheel C

def ladder(save):
    print("Welcome to placeholder for the ladder. Choose where to go from here:")
    choice = game.choose(["Climb to CORE", "Climb to sector B inner ring", "climb to sector B middle ring", "climb to sector B outer ring"])
    if(choice == 0):
        return save.goto("core")
    if(choice == 1):
        return save.goto("innerB")
    if(choice == 2):
        return save.goto("middleB")
    if(choice == 3):
        return save.goto("outerB")

def core(save):
    print("welcome to the placeholder for the core. Where do you wish to go from here?")
    choice = game.choose(["Airlock", "Ladder"])
    if(choice == 0):
        return save.goto("Airlock")
    if(choice == 1):
        return save.goto("ladder")

def innerA(save):
    print("Welcome to the placeholder for inner ring sector A. Where do you wish to go?")
    choice = game.choose(["Inner B"])
    if (choice == 0):
        return save.goto("innerB")

def innerB(save):
    print("Welcome to the placeholder for inner ring sector B. Where do you wish to go?")
    choice = game.choose(["Ladder", "Inner A"])
    if(choice == 0):
        return save.goto("ladder")
    if (choice == 1):
        return save.goto("innerA")

def middleA(save):
    print("Welcome to the placeholder for middle ring sector A. Where do you wish to go?")
    choice = game.choose(["Inner B", "my room"])
    if (choice == 0):
        return save.goto("middleB")
    elif (choice == 1):
        return save.goto("apartment")

def middleB(save):
    print("Welcome to the placeholder for middle ring sector B. Where do you wish to go?")
    choice = game.choose(["Ladder", "Inner A"])
    if(choice == 0):
        return save.goto("ladder")
    if (choice == 1):
        return save.goto("middleA")

def outerA(save):
    print("Welcome to the placeholder for middle ring sector A. Where do you wish to go?")
    choice = game.choose(["Inner B"])
    if (choice == 0):
        return save.goto("outerB")

def outerB(save):
    print("Welcome to the placeholder for middle ring sector B. Where do you wish to go?")
    choice = game.choose(["Ladder", "Inner A"])
    if(choice == 0):
        return save.goto("ladder")
    if (choice == 1):
        return save.goto("outerA")

def wheelCAirlock(save):
    print("Welcome to end of chapter 1")
    