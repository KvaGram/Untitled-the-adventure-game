import game_utilities as game

#barebones placeholder for chapter 1: Wheel C

def ladder(save):
    print("Welcome to placeholder for the ladder. Choose where to go from here:")
    choice = game.choose(["Climb to CORE", "Climb to sector B inner ring", "climb to sector B middle ring", "climb to sector B outer ring"])
    if(choice == 0):
        return game.goto("core", save)
    if(choice == 1):
        return game.goto("innerB", save)
    if(choice == 2):
        return game.goto("middleB", save)
    if(choice == 3):
        return game.goto("outerB", save)

def core(save):
    print("welcome to the placeholder for the core. Where do you wish to go from here?")
    choice = game.choose(["Airlock", "Ladder"])
    if(choice == 0):
        return game.goto("WheelCAirlock", save)
    if(choice == 1):
        return game.goto("ladder", save)

def innerA(save):
    print("Welcome to the placeholder for inner ring sector A. Where do you wish to go?")
    choice = game.choose(["Inner B"])
    if (choice == 0):
        return game.goto("innerB", save)

def innerB(save):
    print("Welcome to the placeholder for inner ring sector B. Where do you wish to go?")
    choice = game.choose(["Ladder", "Inner A"])
    if(choice == 0):
        return game.goto("ladder", save)
    if (choice == 1):
        return game.goto("innerA", save)

def middleA(save):
    print("Welcome to the placeholder for middle ring sector A. Where do you wish to go?")
    choice = game.choose(["Inner B", "my room"])
    if (choice == 0):
        return game.goto("middleB", save)
    elif (choice == 1):
        return game.goto("apartment", save)

def middleB(save):
    print("Welcome to the placeholder for middle ring sector B. Where do you wish to go?")
    choice = game.choose(["Ladder", "Inner A"])
    if(choice == 0):
        return game.goto("ladder", save)
    if (choice == 1):
        return game.goto("middleA", save)

def outerA(save):
    print("Welcome to the placeholder for middle ring sector A. Where do you wish to go?")
    choice = game.choose(["Inner B"])
    if (choice == 0):
        return game.goto("outerB", save)

def outerB(save):
    print("Welcome to the placeholder for middle ring sector B. Where do you wish to go?")
    choice = game.choose(["Ladder", "Inner A"])
    if(choice == 0):
        return game.goto("ladder", save)
    if (choice == 1):
        return game.goto("outerA", save)

def wheelCAirlock(save):
    print("Welcome to end of chapter 1")
    