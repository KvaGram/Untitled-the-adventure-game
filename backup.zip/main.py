import time

import game_utilities as game

def start():
    print("Welcome to")
    f = open("title.txt", 'r', encoding="utf-8")
    titlecard = f.read()
    game.rolltext(titlecard, 0.05)
    f.close()
    time.sleep(1)
    print()
    while(True):
        print("Untitled! The adventure game")
        print("MAIN MENU")
        choices = ["New Game", "Load Game", "About", "End game"]
        choice = game.choose(choices)
        if(choice == 0):
            save = savadata()
            game.goto('apartment', save) #loads first room, starting new game
            print("THE END")
            print("Too soon? Maybe the story is not finished yet.")
            continue
        if(choice == 1):
            game.loadGame() #starts process to load a save
            continue
        if(choice == 2):
            game.goto('about', {}) #starts credits roll
            continue
        if(choice == 3):
            break
class savadata:
    data = {}
    def __init__(self):
        self.data = {}
    def getdata(self, name):
        try:
            return self.data[name]
        except:
            return None
    def setdata(self, name, value):
        self.data[name] = value
start()