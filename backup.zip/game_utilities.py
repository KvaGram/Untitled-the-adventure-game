#this script binds together all scripts such as all others can access each other in a global scope
import sys
import tkinter as tk
from tkinter import filedialog
import time

import room_apartment
import about
import WheelC as wheel
world = {}

def build_world():
    world = {}
    world['apartment'] = room_apartment.main
    world['about'] = about.main
    world["core"] = wheel.core
    world["innerA"] = wheel.innerA
    world["innerB"] = wheel.innerB
    world["middleA"] = wheel.innerA
    world["middleB"] = wheel.innerB
    world["outerA"] = wheel.outerA
    world["outerB"] = wheel.outerB
    world["ladder"] = wheel.ladder
    world["WheelCAirlock"] = wheel.wheelCAirlock

    return world
world = build_world()

def goto(place, save):
    try:
        p = world[place]
    except:
        print("-----")
        print("Sorry, program could not find '{0}' in the system!".format(place))
    
    save.setdata("lastroom", save.getdata("room"))
    save.setdata("room", place)
    return p(save)

def loadGame():
    root = tk.Tk()
    root.withdraw()

    file_path = filedialog.askopenfilename()
    print(file_path)
    #TODO try convert textfile to save-file, and load latest room
    return {}

def choose(list):
    valid = False
    inp = 0 #placeholder value
    while not valid:
        print("\tenter choice number {0} to {1}".format(1, len(list)))
        for i in range (len(list)):
            print ("\t {0} - {1}".format(i+1, list[i]))
        inp = input()
        try:
            inp = int(inp) - 1
        except:
            print("Please enter a valid number")
            continue
        if (inp < 0 or inp >= len(list)):
            print("Sorry, that is not an option.")
            continue
        valid = True
    #print("you chose {0}".format(list[inp-1]))
    return inp

def rolltext(txt, linepause):
    lines = txt.splitlines()
    for l in lines:
        print(l)
        time.sleep(linepause)